<template>
  <h1>App B - Header</h1>
</template>
