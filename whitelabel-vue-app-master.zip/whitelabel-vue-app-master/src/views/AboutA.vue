<template>
  <div class="about">
    <h1>This is the company A about page.</h1>
  </div>
</template>
