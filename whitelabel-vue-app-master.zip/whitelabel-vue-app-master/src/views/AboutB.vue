<template>
  <div class="about">
    <h1>This is the company B about page.</h1>
  </div>
</template>
